// sap.ui.define([
// 	"sap/ui/core/mvc/Controller"
// ], function(Controller) {
// 	"use strict";

// 	return Controller.extend("com.sap.hcp.samples.controller.Detail", {
// 		// The onInit method is called automatically by the framework when
// 		// the view instance has been created
// 		onInit: function() {
// 			var oView = this.getView(), oRouter = this.getOwnerComponent().getRouter();
// 			oRouter.attachRouteMatched(function(oEvent) {
// 				// The 'routeMatched' event is fired whenever a navigation route
// 				// matched...
// 				var mParameters = oEvent.getParameters();
// 				if (mParameters.view === oView) {
// 					// ... but we only want to respond to the event if the route for this
// 					// view/controller was matched
// 					// We then get some parameters from the route parameters
// 					// and bind the view to the product from the url
// 					var mArguments = oEvent.getParameter("arguments");
// 					var sId = mArguments.id;
// 					var aData = oView.getModel().getData();
// 					for (var i = 0; i < aData.length; i++) {
// 						if (aData[i].id === sId) {
// 							break;
// 						}
// 					}
// 					oView.bindElement("/" + i);
// 					// Detail model
// 					var oAppModel = new sap.ui.model.json.JSONModel();
// 					jQuery.getJSON("/myapi/api/v1/plantlist/" + sId + "/mfplantinfo").done(function(mData) {
// 						oAppModel.setData(mData);
// 					});
// 					oView.setModel(oAppModel, "details");
// 					oView.getParent().to(oView);
// 				}
// 			});
// 		}		
		
// 	});

// });