sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("com.sap.hcp.samples.controller.App", {
		onInit: function() {
			var oView = this.getView();
			var plantsDetailModel = new sap.ui.model.json.JSONModel();
			jQuery.getJSON("/multitenantApp/api/v1/plantlist/mfplantinfo/all").done(function(mData) {
				plantsDetailModel.setData(mData);
			});
			oView.setModel(plantsDetailModel, "plantsDetail");
		
			var plantlistModel = new sap.ui.model.json.JSONModel();
			jQuery.getJSON("/multitenantApp/api/v1/plantlist/").done(function(mData) {
				plantlistModel.setData(mData);
			});
			oView.setModel(plantlistModel, "plantlist");

		}

	});
});