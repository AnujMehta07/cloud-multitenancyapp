sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("com.sap.hcp.samples.controller.App", {
		onInit: function() {
		var oView = this.getView();
			var plantsDetailModel = new sap.ui.model.json.JSONModel();
			jQuery.getJSON("/multitenantApp/api/v1/plantlist/mfplantinfo/all").done(function(mData) {
				plantsDetailModel.setData(mData);
			});
		oView.setModel(plantsDetailModel, "plantsDetail");
			var plantlistModel = new sap.ui.model.json.JSONModel();
			jQuery.getJSON("/multitenantApp/api/v1/plantlist/").done(function(mData) {
				plantlistModel.setData(mData);
			});
		oView.setModel(plantlistModel, "plantlist");
			var oVizFrame = [];
			for (var i = 1; i < 4; i++) {
				oVizFrame[i] = this.getView().byId("plant" + i);
				var oDataset = new sap.viz.ui5.data.FlattenedDataset({
					dimensions: [{
						name: 'Date',
						value: {
							path: "ogPlant/dateField"
						}
					}],
					measures: [{
						name: 'Plant O3',
						value: {
							path: "ogPlant/o3"
						}
					}, {
						name: 'City O3',
						value: {
							path: "cityO3"
						}
					}],

					data: {
						path: "plantListModel>/plantAirQualityWeeklyDataList/0/plant10" + i + "AirQualityWeeklyData/"
					}
				});
				oVizFrame[i].setDataset(oDataset);
				oVizFrame[i].setModel(plantlistModel,"plantListModel");
				oVizFrame[i].setModel(plantsDetailModel,"plantsDetailModel");
				sap.ui.getCore().setModel(plantsDetailModel);
				oVizFrame[i].setVizType('line');
				// 4.Set Viz properties
				oVizFrame[i].setVizProperties({
					plotArea: {
						colorPalette: d3.scale.category20().range()
					},
					title: {
						alignment: "left",
						visible: true,
						text:"Comparision of Ozone levels by Plant and City"
						}

				});
				var feedPlantO3Axis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "valueAxis",
						'type': "Measure",
						'values': ["Plant O3"]
					}),
					feedCityO3Axis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "valueAxis",
						'type': "Measure",
						'values': ["City O3"]
					}),
					feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
						'uid': "categoryAxis",
						'type': "Dimension",
						'values': ["Date"]
					});
				oVizFrame[i].addFeed(feedPlantO3Axis);
				oVizFrame[i].addFeed(feedCityO3Axis);
				oVizFrame[i].addFeed(feedCategoryAxis);
			}

		}
		
	});
});