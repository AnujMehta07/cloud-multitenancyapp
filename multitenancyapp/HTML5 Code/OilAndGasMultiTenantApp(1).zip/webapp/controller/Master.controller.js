// sap.ui.define([
// 	"sap/ui/core/mvc/Controller",
// 		"sap/ui/model/Sorter"
// ], function(Controller,Sorter) {
// 	"use strict";
// 	return Controller.extend("com.sap.hcp.samples.controller.Master", {
// 	_showMFPlantInfoForListItem: function(oListItem) {
// 			// Get the binding context from the list item
// 			// The binding context contains the model data for the data record
// 			// that is displayed by the list item.
// 			// By passing the path of the binding context to the router, we
// 			// can use it on the Details view and bind the view to the path
// 			// so that the same data can be displayed
// 			// The check for the context before reading the path is just a
// 			// workaround for the first example where no model is invoked
// 			var oRouter = this.getOwnerComponent().getRouter(), oContext = oListItem.getBindingContext(), sPath = oContext ? oContext.getPath() : "0";
// 			oRouter.navTo("Detail", {
// 				id: oContext.getProperty().id,
// 				path: encodeURIComponent(sPath)
// 			});
// 		},
// 		handleHomeButtonPress: function( /* oEvent */) {
// 			var oRouter = this.getOwnerComponent().getRouter();
// 			oRouter.navTo("Launchpad");
// 		},
// 		handleListItemPress: function(oEvent) {
// 			var oListItem = oEvent.getParameter("listItem");
// 			this._showMFPlantInfoForListItem(oListItem);
// 		},
// 		handleSearch: function(oEvent) {
// 		// create model filter
// 		var filters = [];
// 		var query = oEvent.getParameter("query");
// 		if (query && query.length > 0) {
// 			var filter = new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, query);
// 			filters.push(filter);
// 		}
// 		// update list binding
// 		var list = this.getView().byId("list");
// 		var binding = list.getBinding("items");
// 		binding.filter(filters);
// 		}
// 	});
// });